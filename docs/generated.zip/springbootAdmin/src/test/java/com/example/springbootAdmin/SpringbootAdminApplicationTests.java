package com.example.springbootAdmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
